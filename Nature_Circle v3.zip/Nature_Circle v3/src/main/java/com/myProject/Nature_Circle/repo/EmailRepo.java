package com.myProject.Nature_Circle.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.myProject.Nature_Circle.models.Email;

import java.util.List;

public interface EmailRepo extends JpaRepository<Email, Long> {
    List<Email> findByCompanyNameContaining(String filter);
}
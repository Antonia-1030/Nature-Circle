package com.myProject.Nature_Circle.services;

import com.myProject.Nature_Circle.repo.EmailRepo;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import com.myProject.Nature_Circle.models.Email;

import java.util.List;

@Service
public class EmailService extends BaseService<Email>{

    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private EmailRepo emailRepo;

    @Override
    protected JpaRepository<Email, Long> getRepo() {
        return emailRepo;
    }

    public List<Email> getFilteredEmailsByCompany(String filter){
        return emailRepo.findByCompanyNameContaining(filter);
    }

    public void sendTemplateEmail(String fullName, String companyName,
                                  String clientEmail, String subject, String body,
                                  String emailTo)
            throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();

        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        Context context = new Context();
        context.setVariable("name", fullName);
        context.setVariable("company", companyName);
        context.setVariable("email", clientEmail);
        context.setVariable("subject", subject);
        context.setVariable("body", body);

        String html = templateEngine.process("email/contact", context);

        helper.setFrom("students@leet-soft.com");
        helper.setTo(emailTo);
        helper.setSubject(subject);
        helper.setText(html, true);

        mailSender.send(message);
    }

    public void sendReplyEmail(String title, String body,
                               String clientEmail){

        try{
            SimpleMailMessage message = new SimpleMailMessage();

            message.setTo(clientEmail);
            message.setFrom("students@leet-soft.com");
            message.setSubject(title);
            message.setText(body);

            mailSender.send(message);
        }catch (Exception ex){
            String mess = ex.getMessage();
        }
    }

    public void sendEmail(String fullName, String companyName,
                          String clientEmail, String subject, String body){

        try{
            SimpleMailMessage message = new SimpleMailMessage();

            message.setTo("students@leet-soft.com");
            message.setFrom("students@leet-soft.com");
            message.setSubject(subject);
            message.setText("Message from contant form coming from Mr./Mrs. " + fullName
                    + " working at " + companyName + " and with email " + clientEmail +
                    " wrote the following message: \n" + body);

            mailSender.send(message);
        }catch (Exception ex){
            String mess = ex.getMessage();
        }
    }


}

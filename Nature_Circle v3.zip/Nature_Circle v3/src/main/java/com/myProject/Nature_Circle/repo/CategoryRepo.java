package com.myProject.Nature_Circle.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.myProject.Nature_Circle.models.Category;
@Repository
public interface CategoryRepo extends JpaRepository<Category, Long> {
}
package com.myProject.Nature_Circle.services;

import lombok.AllArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import com.myProject.Nature_Circle.dto.BaseDTO;
import com.myProject.Nature_Circle.dto.CategoryDTO;
import com.myProject.Nature_Circle.models.Category;
import com.myProject.Nature_Circle.repo.CategoryRepo;


@AllArgsConstructor
@Service
public class CategoryService extends BaseService<Category>{
    CategoryRepo categoryRepo;
    @Override
    protected JpaRepository<Category, Long> getRepo() {
        return categoryRepo;
    }
}

package com.myProject.Nature_Circle.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartDTO extends BaseDTO {
    private long ownerId;
}
package com.myProject.Nature_Circle.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import com.myProject.Nature_Circle.models.MainModel;
@Getter
@Setter
@NoArgsConstructor
public abstract class BaseDTO {

    private long id;
}


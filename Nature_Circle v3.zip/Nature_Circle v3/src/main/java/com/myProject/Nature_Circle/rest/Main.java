package com.myProject.Nature_Circle.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.myProject.Nature_Circle.models.Email;
import com.myProject.Nature_Circle.services.EmailService;

@Controller
public class Main {

    @Autowired
    EmailService emailService;

    @GetMapping(path = "/")
    public String getMain(){
        return "homepage.html";
    }

    @GetMapping(path ="/sign-in")
    public String getRegister(){
        return "sign-in.html";
    }

    @GetMapping(path ="/shop")
    public String getShop(){
        return "shop.html";
    }

    @GetMapping(path ="/about")
    public String getAboutPage(){
        return "about.html";
    }

    @GetMapping(path ="/contact")
    public String getContactPage(){

        return "contact.html";
    }

    @RequestMapping("/send-message")
    public String sendContactMessage(@RequestParam(value = "fullName") String name,
                                     @RequestParam(value = "companyName") String company,
                                     @RequestParam(value = "email") String email,
                                     @RequestParam(value = "subject") String subject,
                                     @RequestParam(value = "body") String body){
        try{
            emailService.sendTemplateEmail(name, company, email,subject, body,"students@leet-soft.com");

            Email emailToSave = new Email();
            emailToSave.setBody(body);
            emailToSave.setFromEmail(email);
            emailToSave.setClientName(name);
            emailToSave.setCompanyName(company);
            emailToSave.setSubject(subject);

            emailService.create(emailToSave);

            return "thanks.html";
        }catch (Exception ex){
            return "error";
        }
    }
}
package com.myProject.Nature_Circle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NatureCircleApplicationTests {

	@Test
	void contextLoads() {
	}

}

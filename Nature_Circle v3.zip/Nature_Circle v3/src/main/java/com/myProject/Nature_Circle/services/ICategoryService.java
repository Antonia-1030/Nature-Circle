package com.myProject.Nature_Circle.services;

import com.myProject.Nature_Circle.dto.CategoryDTO;

import java.util.List;

public interface ICategoryService {
    List<CategoryDTO> getAll();

    CategoryDTO getBy(Long id);

    CategoryDTO create(CategoryDTO categoryDTO);

    CategoryDTO update(CategoryDTO categoryDTO);

    boolean remove(long id);
}

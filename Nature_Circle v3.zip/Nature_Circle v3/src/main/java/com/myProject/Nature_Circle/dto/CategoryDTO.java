package com.myProject.Nature_Circle.dto;

import lombok.NoArgsConstructor;
import com.myProject.Nature_Circle.models.Category;

import java.util.List;
@NoArgsConstructor
public class CategoryDTO extends BaseDTO {

    private String name;
    private CategoryDTO parent;
    private List<CategoryDTO> children;
    private int vatPercent;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CategoryDTO getParent() {
        return parent;
    }

    public void setParent(CategoryDTO parent) {
        this.parent = parent;
    }

    public List<CategoryDTO> getChildren() {
        return children;
    }

    public void setChildren(List<CategoryDTO> children) {
        this.children = children;
    }

    public int getVatPercent() {
        return vatPercent;
    }

    public void setVatPercent(int vatPercent) {
        this.vatPercent = vatPercent;
    }
}
